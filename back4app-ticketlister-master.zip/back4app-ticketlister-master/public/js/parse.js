// PART 1: Put your APP ID, JS Key, and SERVER URL

Parse.initialize(
  '', // YOUR APP ID 
  '' // YOUR Javascript  KEY
);
// YOUR SERVER URL
Parse.serverURL = 'https://parseapi.back4app.com';
